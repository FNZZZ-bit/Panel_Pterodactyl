<?php
// === KONFIGURASI PANEL ===
$ptero_url = "https://piyannihdeck.fajarsidikhosting.online";   // ganti pakai domain panelmu
$api_key   = "ptlc_JWpoS1tZTWDcQQ7eYW3SL4hsOMx8U9K6jiFZifmcRKP";             // ganti pakai API Key panelmu

// Data dari form
$username = $_POST['username'] ?? "";
$password = $_POST['password'] ?? "";

// Cek login sederhana (misal Admin/1234)
if ($username === "Admin" && $password === "1234") {

    // Contoh: ambil daftar server via API
    $ch = curl_init("$ptero_url/api/application/servers");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer $api_key",
        "Content-Type: application/json",
        "Accept: Application/vnd.pterodactyl.v1+json"
    ]);
    $result = curl_exec($ch);
    curl_close($ch);

    echo "<h2>Login berhasil!</h2>";
    echo "<pre>$result</pre>";

} else {
    echo "<h2>Login gagal, coba lagi!</h2>";
}
?>